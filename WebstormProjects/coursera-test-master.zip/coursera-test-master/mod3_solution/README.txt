Assignment 3
