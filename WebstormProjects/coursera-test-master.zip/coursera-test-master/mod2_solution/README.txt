Assignment 2
