# coursera
AngularJS project which encorporates promises, retrieves JSON file and utilizes search capabilities.
