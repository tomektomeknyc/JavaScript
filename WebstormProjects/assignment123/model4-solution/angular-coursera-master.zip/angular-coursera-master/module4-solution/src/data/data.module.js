(function () {
'use strict';

angular.module('Data', ['ui.router']);

})();
