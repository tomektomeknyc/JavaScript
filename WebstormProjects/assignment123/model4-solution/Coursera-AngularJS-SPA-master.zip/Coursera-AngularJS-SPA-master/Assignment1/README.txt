Solution for the assignment in module 1
