(function () {
  'use strict';
  angular.module('MenuApp',['data', 'ui.router']);
})();
